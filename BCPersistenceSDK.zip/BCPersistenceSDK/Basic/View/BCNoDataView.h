//
//  BCNoDataView.h
//  BichanWallet
//
//  Created by 王青海 on 2018/8/10.
//  Copyright © 2018年 陈少楠. All rights reserved.
//

#import "BCUIKit.h"

@interface BCNoDataView : UIView

@property (nonatomic, weak) BCLabel *label;

@end
