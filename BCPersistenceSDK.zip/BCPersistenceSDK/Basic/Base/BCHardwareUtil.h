//
//  BCHardwareUtil.h
//  BichanWallet
//
//  Created by 王青海 on 2018/9/21.
//  Copyright © 2018年 陈少楠. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BCHardwareUtil : NSObject


+ (BOOL)isSimulator;


+ (BOOL)isJailBreak;

@end

