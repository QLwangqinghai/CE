//
//  BCTableView.h
//  BCUIKit
//
//  Created by 王青海 on 2018/8/2.
//  Copyright © 2018年 王青海. All rights reserved.
//

#import <UIKit/UIKit.h>


/**
 UITableView 的 简易封装， 默认去掉估算高度， 需要估算高度的地方需要自行设置
 */
@interface BCTableView : UITableView

@end
