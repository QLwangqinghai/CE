//
//  BCDecimalNumberUtil.h
//  BichanWallet
//
//  Created by 王青海 on 2018/9/11.
//  Copyright © 2018年 陈少楠. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BCDecimalNumberUtil : NSObject


+ (NSDecimalNumber *)numberWithString:(NSString *)string;



@end
