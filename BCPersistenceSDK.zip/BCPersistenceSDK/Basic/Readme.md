# Basic


## Base 
> 基础功能封装 (Foundation 以及一些底层C库的封装)
>
> 禁止依赖外部

## BaseUI 
> UI控件的封装、只能依赖Base目录下文件 以及 网络库、三方的UI库 等 禁止依赖业务


## Controller
> 业务层的一些controller封装

## Model
> 业务层用的一些model

## View
> 业务层用的一些View
