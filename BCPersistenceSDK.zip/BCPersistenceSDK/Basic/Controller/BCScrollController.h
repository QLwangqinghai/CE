//
//  BCScrollController.h
//  BichanWallet
//
//  Created by 王青海 on 2018/8/13.
//  Copyright © 2018年 陈少楠. All rights reserved.
//

#import "BCViewController.h"

@interface BCScrollController : BCViewController

@property (nonatomic, weak, readonly) BCScrollView *scrollView;
@property (nonatomic, weak, readonly) UIView *contentView;


@end
